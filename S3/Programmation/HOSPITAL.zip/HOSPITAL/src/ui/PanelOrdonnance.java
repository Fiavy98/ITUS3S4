package ui;

import acte.*;
import db.*;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

public class PanelOrdonnance extends JPanel {

    // Description
    private String IDORD;
    private String IDMVT;

    private JTextField txtDate, txtNbJr, txtObservation;
    private Vector<String[]> Medicament;
    private JList<String> lsMedicaments;
    private Map<String, JTextField> sortie = new HashMap<>();
    private JButton ajord;
    private JButton btnOrdF;

    // Client
    private JTextField nom, telephone, adresse;
    private Vector<String[]> Societe;
    private Map<String, String> MapSos = new HashMap<>();
    private JComboBox<String> lsSociete;

    //Stock
    private JTextField stkDate;
    private Vector<String[]> Magasin;
    private JComboBox<String> lsMagasin;

    //Livrer
    private JTextField LvrDate;
    private Vector<String> lsForn;
    private JComboBox<String>  Forn;

    // Résultat
    private JTextArea txtResultat;

    public PanelOrdonnance() {
        setLayout(new BorderLayout(10, 10));

        txtResultat = new JTextArea();

        //============================Description=================================
        JPanel panelDescription = new JPanel();
        panelDescription.setLayout(new BoxLayout(panelDescription, BoxLayout.Y_AXIS));
        panelDescription.setBorder(BorderFactory.createTitledBorder("Description"));

        //----------------ORDONNANCE----------------
        txtDate = new JTextField(15);
        txtNbJr = new JTextField(15);
        txtObservation = new JTextField(15);
        ajord = new JButton("valider");


        panelDescription.add(labeledPanel("Date:", txtDate));
        panelDescription.add(labeledPanel("Nombre de jours:", txtNbJr));
        panelDescription.add(labeledPanel("Observation:", txtObservation));
        panelDescription.add(ajord);

        //------------------ ORDONANCEFILLE ---------------
        //Medicaments
        Medicament = From_Medicament.lsMedicament();
        String[] nomsMed = Medicament.stream().map(m -> m[1]).toArray(String[]::new);
        lsMedicaments = new JList<>(nomsMed);
        lsMedicaments.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollMed = new JScrollPane(lsMedicaments);
        scrollMed.setPreferredSize(new Dimension(200, 100));

        panelDescription.add(new JLabel("Médicaments:"));
        panelDescription.add(scrollMed);

        //Quantités
        JPanel panelQuantites = new JPanel();
        panelQuantites.setLayout(new BoxLayout(panelQuantites, BoxLayout.Y_AXIS));
        panelDescription.add(panelQuantites);

        lsMedicaments.addListSelectionListener(e -> {
            panelQuantites.removeAll();
            sortie.clear();       
        
            for (String med : lsMedicaments.getSelectedValuesList()) {
                JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
                panelQuantites.add(row);
        
                JTextField qte = new JTextField(5);
                row.add(new JLabel(med + "  Quantite:"));
                row.add(qte);
                sortie.put(med, qte);
            }
        
            panelQuantites.revalidate();
            panelQuantites.repaint();
        });
        
        //=========================Client=============================
        JPanel panelClient = new JPanel();
        panelClient.setLayout(new BoxLayout(panelClient, BoxLayout.Y_AXIS));
        panelClient.setBorder(BorderFactory.createTitledBorder("Client"));

        nom = new JTextField(15);
        telephone = new JTextField(15);
        adresse = new JTextField(15);

        Societe = From_societe.lsSociete();
        lsSociete = new JComboBox<>();
        for (String[] sos : Societe) {
            String id = sos[0];
            String nomSoc = sos[1];
            lsSociete.addItem(nomSoc);
            MapSos.put(nomSoc, id);
        }

        btnOrdF = new JButton("valider Ordonnance");
        JPanel btnPanel = new JPanel();
        btnPanel.add(btnOrdF);

        panelClient.add(labeledPanel("Nom:", nom));
        panelClient.add(labeledPanel("Société:", lsSociete));
        panelClient.add(labeledPanel("Téléphone:", telephone));
        panelClient.add(labeledPanel("Adresse:", adresse));
        panelClient.add(btnOrdF);


        //-----------------INS ORDONNANCE-------------------
        btnOrdF.setEnabled(false);
        

    ajord.addActionListener(e -> {
        try {
            if (IDORD == null) {
                String dt = txtDate.getText();
                int nbJr = Integer.parseInt(txtNbJr.getText());
                String obs = txtObservation.getText();

                String societer = (String) lsSociete.getSelectedItem();
                String id_soc = MapSos.get(societer);

                DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                LocalDate date = LocalDate.parse(dt, format);
                java.sql.Date ins_Date = java.sql.Date.valueOf(date);

                IDORD = From_MedOrdon.insOrd(
                    ins_Date, nbJr, obs, From_Medecin.getIdMedecin(Session.getUserId()), id_soc
                );
                btnOrdF.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(null, "Ordonnance déjà créée");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    });

      btnOrdF.addActionListener(e -> {
        if (IDORD == null) {
            JOptionPane.showMessageDialog(null, "Crée l'ordonnance parent d'abord (ajord).");
            return;
        }
        try {
            new ActionOrdonnance(
                IDORD, txtDate, txtNbJr, txtObservation, lsMedicaments, sortie,
                nom, telephone, adresse, lsSociete, txtResultat, MapSos
            ).actionPerformed(e);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Erreur : " + ex.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
        }
        });


        JPanel panelTop = new JPanel();
        panelTop.setLayout(new GridLayout(1, 2, 10, 0));
        panelTop.add(panelDescription);
        panelTop.add(panelClient);
        add(panelTop, BorderLayout.NORTH);

        //Result
        txtResultat.setEditable(false);
        txtResultat.setFont(new Font("Serif", Font.PLAIN, 16));
        txtResultat.setBorder(BorderFactory.createTitledBorder("Ordonnance"));
        add(new JScrollPane(txtResultat), BorderLayout.CENTER);


        //========================= Inv and Livrer =================================
        JPanel panelBas = new JPanel();
        panelBas.setLayout(new GridLayout(1, 2, 10, 0)); 
                
        // ========STOKAGE==========
        JPanel panelInventaire = new JPanel();
        panelInventaire.setLayout(new GridLayout(3, 2, 5, 5)); 
        panelInventaire.setBorder(BorderFactory.createTitledBorder("Pharmacie"));
                
        //Dt
        stkDate = new JTextField(15);
        panelInventaire.add(new JLabel("Date :"));
        panelInventaire.add(stkDate);
        
        //Magasin
        Magasin = From_Magasin.lsMagasin();
        lsMagasin = new JComboBox<>();
        for (String[] mag : Magasin) {
            lsMagasin.addItem(mag[1]);
        }
        panelInventaire.add(new JLabel("Magasin :"));
        panelInventaire.add(lsMagasin);
        
        // ACTION SORTIE STOCK
        JButton btnSTK = new JButton("Valider");
        btnSTK.addActionListener (e -> {
            String dt = stkDate.getText();
            LocalDate date = LocalDate.parse(dt, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            java.sql.Date ins_Date = java.sql.Date.valueOf(date);
        
            String Mag = (String) lsMagasin.getSelectedItem();
            String idMang = From_Magasin.getIdmagasin(Mag);
   
            IDMVT = From_Stock.insMvtSock_sortie(ins_Date, idMang);
        
            ActionStKSort act = new ActionStKSort(IDMVT, lsMedicaments, sortie);
            act.execute(); 
        });
        


        panelInventaire.add(new JLabel()); 
        panelInventaire.add(btnSTK);
        
        //===========Livrer===========
        JPanel panelLivrer = new JPanel();
        panelLivrer.setLayout(new GridLayout(3, 2, 5, 5)); // 3 lignes, 2 colonnes
        panelLivrer.setBorder(BorderFactory.createTitledBorder("Livrer"));
        
        //Dt
        LvrDate = new JTextField(15);
        panelLivrer.add(new JLabel("Date :"));
        panelLivrer.add(LvrDate);
        
        //Fournisseur
        lsForn = From_Livraison.lsFourniseur();
        Forn = new JComboBox<>();
        for (String forn : lsForn) {
            Forn.addItem(forn);
        }
        panelLivrer.add(new JLabel("Fournisseur :"));
        panelLivrer.add(Forn);
        
        //Btn
        JButton btnLivrer = new JButton("Livrer");
        panelLivrer.add(new JLabel()); 
        panelLivrer.add(btnLivrer);

        //ACTION
        btnLivrer.addActionListener(new ActionLivrer(lsMedicaments, sortie,
            nom, telephone, adresse, lsSociete, MapSos, LvrDate, Forn));
        
        panelBas.add(panelInventaire);
        panelBas.add(panelLivrer);
        
        add(panelBas, BorderLayout.SOUTH);

        
    }

    // label + composant
    private JPanel labeledPanel(String label, JComponent comp) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        panel.add(new JLabel(label));
        panel.add(comp);
        return panel;
    }
}
